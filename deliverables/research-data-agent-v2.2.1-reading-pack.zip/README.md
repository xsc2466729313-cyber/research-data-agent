# 科研数据智能体（Research Data Agent）

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/xsc2466729313-cyber/research-data-agent)

![文档版本](https://img.shields.io/badge/docs-v2.2.1-2563eb) ![运行时版本](https://img.shields.io/badge/runtime-2.2.0--qwen--agent-0f766e) ![用途](https://img.shields.io/badge/use-research--data%20evidence-0f766e)

**面向肿瘤学、生物医学、天文学及通用科研的统一自主科研数据智能体。**

当前文档与截图发布版：`v2.2.1`（视觉/交付修订）；后端运行时版本保持 `2.2.0-qwen-agent`。

本项目把自然语言科研问题转成可执行、可核验的数据工作流：先形成研究条件清单，再检索真实论文与公开数据库，完成字段标准化、患者/样本关联、来源登记、医学安全检查和缺口驱动的闭环补查，最后输出可分析、可追溯的数据资产与质量报告。乳腺癌是当前专项验证场景，系统同时支持 17 个其他常见癌种，并为未配置癌种保留通用发现入口。

> 模型负责理解、规划与反思；公开数据库提供事实；确定性规则负责字段治理、医学安全和发布边界。本项目用于科研数据整理与证据审查，不提供临床诊断或个体治疗建议。

**在线演示：** [打开科研数据智能体](https://cancer-precision-data-agent.onrender.com/)

公网地址当前沿用历史域名；仓库内部展示名和英文标识统一为“科研数据智能体 / research-data-agent”。Render 免费实例长时间无访问后会休眠，首次打开可能需要等待几十秒。

### GitHub 快速导航

| 你想先看什么 | 入口 |
|---|---|
| 直接体验 | [在线演示](https://cancer-precision-data-agent.onrender.com/) |
| 了解系统如何协作 | [Agent 架构说明](docs/AGENT_ARCHITECTURE.md) · [中文流程图](docs/AGENT_WORKFLOW_CN.md) |
| 查看当前截图 | [前端与内核截图索引](docs/FRONTEND_SCREENSHOT_INDEX.md) |
| 阅读完整交付 | [最终交付索引](docs/FINAL_DELIVERY_INDEX.md) · [v2.2.1 阅读包](deliverables/research-data-agent-v2.2.1-reading-pack.zip) |
| 本地启动 | [快速启动](#快速启动) · [首次使用千问](#首次使用千问) |

### 30 秒看懂这套系统

```text
科研问题 → 研究条件与字段 → 真实来源检索 → 标准化/身份对齐
        → 来源与医学安全校验 → 质量门（PASS / REVIEW / FAIL）
        → 可分析、可追溯的数据资产
```

仓库首页的截图用于解释页面关系；真实任务结果单独标注 task ID、行列数、来源数和质量门状态。截图中的 `PASS` 是对应任务的运行状态，不是统一 benchmark 分数，也不构成临床结论。

## 当前前端入口

根地址现在打开的是“新研究 / 提出方向”规划工作台。左侧五阶段导航负责推进研究，中央区域承载示例问题与输入框，右侧标签页用于查看研究依据、研究方案、数据准备和覆盖矩阵。先看干净原图：

<img src="docs/images/frontend-home-clean-20260906.png" alt="科研规划工作台（桌面原图）" width="820">

下面附有一张红色框、箭头和中文文字说明版，方便快速了解页面分区；说明放在画布外，不遮挡原界面：

<img src="docs/images/frontend-home-annotated-20260906.png" alt="科研规划工作台（桌面标注图）" width="820">

- **左侧五阶段导航**：提出方向 → 查找依据 → 明确问题 → 制定方案 → 准备数据。
- **中央示例卡片**：覆盖 Ia 型超新星、乳腺癌疗效、乳腺癌生物标志物和胰腺癌 KRAS/TP53 等入口，帮助快速形成研究问题。
- **底部输入区**：输入一句研究问题后点击“发送并开始研究”，系统才进入真实规划流程；未配置千问时会先提示连接 API。
- **右侧审查区**：研究开始后展示论文依据、研究方案、数据准备状态和覆盖矩阵，不把空结果伪装成已完成数据。

在移动端，输入区、示例卡片和右侧审查标签会按屏幕宽度依次排列。这里同时保留原图和红色框/箭头/文字说明版：

<img src="docs/images/frontend-home-mobile-clean-20260906.png" alt="移动端科研规划工作台（原图）" width="390">

<img src="docs/images/frontend-home-mobile-annotated-20260906.png" alt="移动端科研规划工作台（标注图）" width="560">

科研助手（科研兔）不是输入区的一部分，单独面板特写如下：

<img src="docs/images/research-companion-panel-annotated-20260906.png" alt="科研助手（科研兔）面板红色讲解标注" width="640">

Agent 架构说明见 [`docs/AGENT_ARCHITECTURE.md`](docs/AGENT_ARCHITECTURE.md)，中文流程图见 [`docs/AGENT_WORKFLOW_CN.md`](docs/AGENT_WORKFLOW_CN.md)：

<img src="frontend/agent-workflow-cn.svg" alt="Agent 中文协作工作流" width="820">

系统属于有边界的混合式多 Agent 编排：任务级主 Agent 统筹规划、采集、批评、质量门和闭环控制；官方数据、字段治理与医学安全由独立确定性模块负责。当前入口恢复与验收说明见 [`docs/FRONTEND_RECOVERY_REPORT_20260906.md`](docs/FRONTEND_RECOVERY_REPORT_20260906.md)。

### 内核实验室前端与真实运行

访问 `/?surface=kernel` 可以查看内核实验室前端。干净壳层用于说明入口和角色分工，红色讲解版把内核总览、Agent 架构、Runtime 和任务入口分别指给读者；空闲 Runtime 的“待运行”不代表已经完成任务。

<img src="docs/images/kernel-lab-desktop-annotated-20260906.png" alt="内核实验室桌面前端（红色讲解标注）" width="820">

<img src="docs/images/kernel-lab-agent-architecture-annotated-20260906.png" alt="内核实验室 Agent 架构流程图（红色讲解标注）" width="820">

后端真实运行证据单独收录在 [前端与内核截图索引](docs/FRONTEND_SCREENSHOT_INDEX.md)；其中 `loop-91ef39cffd32:r3` 运行显示 156 行 × 19 列、Agent Runtime 7/7、四层质量门 PASS。它是可复核运行快照，不是统一 benchmark 成绩。

<img src="docs/images/kernel-lab-live-loop91-her2-20260906-runtime.png" alt="后端真实运行 Agent Runtime（loop-91ef39cffd32:r3）" width="820">

<img src="docs/images/kernel-lab-live-loop91-her2-20260906-quality-gate.png" alt="后端真实运行四层质量门（loop-91ef39cffd32:r3）" width="820">

按参考图重新绘制的当前版本讲解图如下：第一张把四层质量门、患者/样本结构化计数和主表入口放在同一视口；第二张打开当前任务首个样本的原始特征弹窗，分别标出标准化值、原始值和可回查说明。两张图均使用红色框、箭头和中文文字，不覆盖关键界面内容。

<img src="docs/images/kernel-lab-current-quality-data-callout-20260906.png" alt="当前版本质量门与结构化数据红框讲解图" width="820">

<img src="docs/images/kernel-lab-current-raw-characteristics-callout-20260906.png" alt="当前版本原始样本特征弹窗红框讲解图" width="820">

这两张图来自真实任务 `loop-91ef39cffd32:r3`：69 名患者、156 个样本、四层质量门 `PASS`。弹窗首屏只展示可读的前 8 行，滚动条和底部说明明确表示其余原始记录仍可继续复核；它们是界面讲解图，不是新的 benchmark 成绩。

## 当前能力

| 环节 | 已实现能力 | 交付结果 |
|---|---|---|
| 问题理解 | 从研究方向生成候选问题与 Research Contract | 人群、暴露、结局、字段和来源约束 |
| 真实取数 | GDC、GEO、cBioPortal、AACT、CIViC、DepMap 与论文表格/图注 | 带真实 `source_id` 的原始记录 |
| 数据整合 | Schema 匹配、实体关联、医学字段归一化 | 保留 `raw_field`、`raw_value` 的标准表 |
| 质量控制 | 来源、字段、实体、研究适用性四层质量门 | PASS / REVIEW / FAIL 与问题清单 |
| 自主闭环 | 根据缺字段、结局域错配和来源不足规划下一轮补搜 | 两轮指标快照、动作与输入/输出哈希 |
| 多癌种扩展 | 乳腺癌专项流程与 17 个其他常见癌种配置 | 按癌种加载研究上下文与安全边界 |
| 导出审计 | CSV、Excel、Evidence 与运行报告 | 可追溯科研数据包 |

## 核心对照结果

| 能力 | 本项目方法与结果 | 对照方法与结果 | 差值 |
|---|---:|---:|---:|
| 问题解析（EBM-NLP） | 序列特征解析：**0.5522** | 项目词典：0.4662 | **+0.0860** |
| 科学检索（BEIR 五任务主对照） | BM25+BGE 名次融合：**0.3915** | BGE 单路：0.3880 | **+0.0035** |
| 字段匹配（Valentine） | 千问辅助：**0.9018** | 项目原方法：0.7994；COMA：0.7670 | **+0.1024；+0.1348** |
| 实体匹配（DeepMatcher） | 自适应融合：**0.7449** | RecordLinkage：0.7440 | **+0.0009** |
| 数据清洗（Raha/HoloClean） | 来源锚点第6版：**0.9169**（六项） | Raha：0.8159（五项共同任务） | **+0.0870**（共同五项） |
| 乳腺癌专项完整链路（候选卷观察） | 千问 3.8-Max + 真实来源 + 规则核验：**SDTI 98.1118** | 确定性消融：SDTI 100.00 | 均 `publish_allowed=false`，不是封存正式成绩 |

上表中的公开数据集结果是在各自官方测试划分上完成的，分数只在同一能力内部比较，不相加为总准确率。98.1118 是候选卷的严格千问在线观察值，100.00 是同一候选卷的确定性消融值；两者都不是封存 `frozen_test` 正式成绩，也不代表自动发布许可。

## 快速启动

需要 Python 3.11+。首次启动：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r backend\requirements.txt
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
```

打开 <http://127.0.0.1:8000/>。Docker 用户可运行 `./scripts/docker_up.ps1`，然后访问 <http://localhost:8888>。

千问凭据只在会话或本机环境变量中配置，不要提交 `.env` 或任何密钥。

## 首次使用千问

点击首页的“发送并开始研究”或技术详情页的“运行研究协议”时，系统会先检查千问是否已配置。未配置时会弹出提示；点击“去配置 API”，填写百炼 API Key 后测试连接即可继续。默认模型为 `Qwen3.8-Max`（配置标识：`qwen3.8-max`）。

通过网页填写的连接字段保存在当前浏览器本机，用于后端重启后的自动重建；后端实际会话最长保留两小时，只存在当前进程内存中。点击“清除本机连接”或清除站点数据即可删除浏览器保存内容，不会写入项目文件。需要跨浏览器长期可用时，在部署平台或本机环境变量中配置 `DASHSCOPE_API_KEY`。

## 云端部署（推荐 Render）

仓库已提供根目录 `Dockerfile` 和 `render.yaml`，可直接部署为一个公开 Web 服务。FastAPI 会同时托管前端页面和 `/api/*` 接口，云平台只需要一个服务。

1. 将仓库推送到 GitHub，并在 Render 选择 **New + → Blueprint**，选择该仓库；Render 会读取 `render.yaml`。
2. 本公开部署不预置 `DASHSCOPE_API_KEY`，避免所有访客共用你的模型额度。用户首次运行时在网页的“连接千问 API”窗口填写自己的百炼 API Key；该 Key 只保存在当前浏览器，并由后端以最长两小时的进程内存会话临时使用。需要服务器统一使用一个 Key 时，再在 Render 的 Environment 中单独配置 `DASHSCOPE_API_KEY`，不要写进仓库。
3. 部署完成后访问 Render 分配的 `https://<service>.onrender.com/`；健康检查为 `/health`，API 文档为 `/docs`。

也可以在 Railway、Fly.io 或任意支持 Docker 的平台使用同一个根目录 `Dockerfile`。平台必须把外部端口通过 `PORT` 环境变量传入；容器默认监听 `8000`。不要把 API Key 写入仓库或提交 `.env`。

## 报告导航

| 报告 | 用途 |
|---|---|
| [最终交付索引](docs/FINAL_DELIVERY_INDEX.md) | 最新交付物与最终正文入口 |
| [前端与内核截图索引](docs/FRONTEND_SCREENSHOT_INDEX.md) | 干净原图、红色讲解版、真实运行证据和流程图总表 |
| [项目正文报告](docs/PROJECT_REPORT.md) | 项目设计、数据整合流程与最终展示 |
| [评委讲解稿](docs/REVIEWER_STORY.md) | 从研究问题到可信数据交付的口头汇报主线 |
| [数据来源、数据集与参数依据总表](docs/03_数据源与测试数据集.md) | 问题驱动的指标闭环讲解，以及业务数据集、公开评测集、Gold Set、清洗流程和参数/规则依据 |
| [公开数据集统一对照报告](evaluation/PUBLIC_DATASET_COMPARISON_20260902.md) | 问题解析、科学检索、字段匹配、实体匹配、清洗的真实逐任务指标、消融和 API 条件实验 |
| [公开检索统一多方法矩阵](evaluation/PUBLIC_RETRIEVAL_MATRIX_20260903.md) | 同一公开测试集上的多种方法、命中率、召回率、排序质量和耗时 |
| [发布阅读包 ZIP](deliverables/research-data-agent-v2.2.1-reading-pack.zip) | 当前 v2.2.1 正文、截图、图示、公开对照与必要证据发布包 |
| 历史版本说明 | [RELEASE_NOTES.md](RELEASE_NOTES.md)（保留历史口径，不再附带重复压缩包） |
| [v2.2.1 发布说明](RELEASE_NOTES.md) | 截图、流程图和阅读包修订；运行时 API 仍为 `2.2.0-qwen-agent` |

## 复现评测与图表

外部依赖准备完成后，可重跑 GitHub 同类项目评测：

```powershell
python scripts\run_github_competitor_benchmark.py --external-package-dir <外部评测依赖目录>
python scripts\build_github_report_charts.py
```

三层公开能力评测可分别复现：

```powershell
python scripts\run_public_problem_benchmark.py
python scripts\run_public_retrieval_benchmark.py --dataset beir_scifact
python scripts\run_public_retrieval_benchmark.py --dataset beir_trec_covid --method bm25 --method project_bm25_tuned_v2 --method project_hybrid
python scripts\build_public_retrieval_matrix.py
python scripts\run_public_cleaning_benchmark.py
```

当前公开主结果为：EBM-NLP 问题解析平均片段 F1 `0.5522`，BEIR 五任务检索前十条排序质量 `0.3915`（名次融合，公开 BGE 为 `0.3880`），新增 TREC-COVID 医学文献任务 50 个测试问题，并补齐 FiQA 与 Quora 的关键词对照；Valentine 字段对齐 F1 `0.9018`，DeepMatcher 实体匹配 F1 `0.7449`，Raha/HoloClean 六任务错误单元 F1 `0.9169`。仓库只保留上述报告实际引用的公开运行证据，其他重复运行可由脚本重新生成。

公开数据集的完整统一对照、实体匹配结果、逐任务消融和“为什么问题解析/检索偏低”的分析见 [`evaluation/PUBLIC_DATASET_COMPARISON_20260902.md`](evaluation/PUBLIC_DATASET_COMPARISON_20260902.md)；检索的多方法、多指标同表见 [`evaluation/PUBLIC_RETRIEVAL_MATRIX_20260903.md`](evaluation/PUBLIC_RETRIEVAL_MATRIX_20260903.md)，机器可读结果见 [`evaluation/public_benchmarks/retrieval_matrix_20260903.json`](evaluation/public_benchmarks/retrieval_matrix_20260903.json)。

图表直接读取 `results.json`，不在绘图代码中填写成绩。完整逐方法指标、数据哈希和运行环境均保留在评测产物中。

## 医学安全边界

- HER2 IHC 2+ 不得直接自动判为 HER2 Positive。
- ERBB2 CNA amplification 不等同 HER2 IHC positive。
- 低置信度患者/样本关联进入 `unresolved/review`。
- 高权威来源存在不可解释冲突时不得自动选边。
- 细胞系 `AUC/IC50` 与患者 `pCR/response` 必须用 `response_domain` 区分。
- 关键字段缺少 Evidence 时禁止自动发布。

## 验证

```powershell
python -m pytest -q
node --check frontend\app.js
```

验收时运行后端测试和前端语法检查；最终交付内容以 [最终交付索引](docs/FINAL_DELIVERY_INDEX.md) 和 [项目正文报告](docs/PROJECT_REPORT.md) 为准。

项目入口与硬约束见 [README_START_HERE.md](README_START_HERE.md) 和 [AGENTS.md](AGENTS.md)。
