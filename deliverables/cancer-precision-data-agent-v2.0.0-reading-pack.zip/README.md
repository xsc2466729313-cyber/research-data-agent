# 论文及图示阅读包

本阅读包只包含论文终稿、正文图示、公开数据集对照、冻结评价规则和论文实际引用的运行证据，不包含项目源码、历史草稿、失败版本或打包中间文件。

在线演示入口：<https://cancer-precision-data-agent.onrender.com/>

## 阅读方式

1. 优先打开 `docs/论文_浏览器版.html`，普通浏览器即可显示正文、表格和图片。
2. 需要查看原始文本时，打开 `docs/PROJECT_REPORT.md`。
3. 公开任务的完整对照见 `evaluation/PUBLIC_DATASET_COMPARISON_20260902.md`，检索多方法对照见 `evaluation/PUBLIC_RETRIEVAL_MATRIX_20260903.md`。
4. 评价规则见 `configs/`，机器可读结果和报告引用的运行记录见 `evaluation/` 与 `goldset/`。

论文中的图片使用相对路径。请先完整解压压缩包，再打开 HTML 或 Markdown 文件，不要只从压缩软件中单独打开正文。

完整源码、运行说明和公开数据下载入口见：<https://github.com/xsc2466729313-cyber/cancer-precision-data-agent>
