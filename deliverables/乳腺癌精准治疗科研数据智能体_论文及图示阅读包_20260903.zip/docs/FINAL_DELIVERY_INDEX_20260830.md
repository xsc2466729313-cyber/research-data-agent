# 最终交付索引（2026-09-02）

本页是仓库的统一入口，只保留最终正文、最新评委阅读包和当前最佳结果。

## 推荐入口

| 内容 | 文件 |
|---|---|
| 最终正文报告 | [专业叙事与规范图示终稿](乳腺癌精准治疗科研数据智能体_专业叙事与规范图示终稿_20260831.md) |
| 论文及图示阅读包 | [README_START_HERE.md](../README_START_HERE.md) |
| 项目使用说明 | [README_START_HERE.md](../README_START_HERE.md) |

## 核心结果

| 指标 | 结果 |
|---|---:|
| 严格千问在线候选结果 | **SDTI 98.1118** |
| 真实 Qwen 字段匹配 | **Macro F1 0.9018** |

说明：`98.1118` 来自 2026-09-02 的 `official_candidate` 候选卷，11/11 题实际调用千问且 0 次确定性兜底；题集尚未封存为 `frozen_test`，因此不作为正式冻结成绩。固定规划的数据链开发复测另为 SDTI `99.45`。

## 启动

```powershell
python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000 --reload
```
