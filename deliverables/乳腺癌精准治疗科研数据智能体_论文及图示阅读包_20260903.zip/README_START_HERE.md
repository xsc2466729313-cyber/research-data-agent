# 乳腺癌精准治疗科研数据智能体：论文阅读包

这是论文及其图示的精简交付包，不包含项目源码、前后端、配置、测试或内部运行目录。

## 阅读顺序

1. 打开 `docs/乳腺癌精准治疗科研数据智能体_专业叙事与规范图示终稿_20260831.md`。
2. 论文中的图片会从同目录下的 `docs/images/` 自动加载。
3. 公开数据集的逐任务结果见 `evaluation/PUBLIC_DATASET_COMPARISON_20260902.md`，机器可读指标见同名 JSON 文件。
4. 公开对照的方法说明见 `docs/PUBLIC_COMPARISON_GUIDE_20260902.md`。

建议使用 VS Code、Typora 或 Obsidian 等支持 Markdown 图片的阅读器打开论文。解压后请保持 `docs/` 与 `docs/images/` 的相对位置不变。

## 论文中的最新公开结果

- EBM-NLP 问题解析：Macro span F1 `0.5522`
- BEIR 科学检索：Macro nDCG@10 `0.3920`
- Valentine 字段匹配（Qwen）：Macro F1 `0.9018`
- DeepMatcher 实体匹配：Macro F1 `0.7449`
- Raha/HoloClean 数据清洗：Macro Cell F1 `0.9169`
- 严格千问在线候选链路：SDTI `98.1118`；11/11 题调用千问，0 次确定性兜底。该结果属于 `official_candidate`，尚未封存为 `frozen_test`，不作为正式冻结成绩。

包内只保留成功完成且可复核的公开结果证据；失败 API 请求、欠费回退和未完成运行没有打包。
